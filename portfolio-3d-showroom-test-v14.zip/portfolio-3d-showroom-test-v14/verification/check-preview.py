"""Run with Python Playwright; serve showroom/v14 on loopback port 8014."""
from pathlib import Path
import json, sys
from playwright.sync_api import sync_playwright, expect

root=Path(__file__).resolve().parents[1]
results=json.loads((root/'verification/results.json').read_text()) if '--standalone-only' in sys.argv else []
expect.set_options(timeout=20000)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader'])
 for width,url in [(1440,'http://127.0.0.1:8014/'),(820,'http://127.0.0.1:8014/'),(1280,'http://127.0.0.1:8014/standalone-preview.html')]:
  if '--standalone-only' in sys.argv and width!=1280: continue
  context=browser.new_context(viewport={'width':width,'height':1000})
  page=context.new_page();errors=[];external=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:external.append(r.url) if r.url.startswith('https:') else None)
  page.goto(url,wait_until='networkidle');page.wait_for_timeout(1800)
  page.locator('button[data-explore="jbl"]').click()
  expect(page.locator('#try-preview')).to_be_visible(timeout=20000)
  page.evaluate("window.scrollTo({top:document.querySelector('#museum-frame').getBoundingClientRect().top+scrollY-95,behavior:'instant'})")
  page.wait_for_timeout(1700)
  iframe=page.frame_locator('#screen-portal iframe')
  expect(iframe.locator('#nav')).to_be_attached()
  frame=next(f for f in page.frames if f!=page.main_frame)
  frame_id=frame.evaluate('performance.timeOrigin')
  page.locator('#try-preview').click(force=True)
  print('Entered demo',width,flush=True)
  expect(page.locator('#museum-frame')).to_have_class(__import__('re').compile(r'is-demo'))
  expect(page.locator('.demo-badge')).to_be_visible()
  assert not page.locator('.demo-workspace').evaluate('(e)=>e.inert')
  expect(page.locator('#try-preview')).to_have_attribute('aria-pressed','true')
  expect(page.locator('#screen-portal')).to_have_css('pointer-events','auto')
  page.wait_for_timeout(1400)
  iframe.locator('#nav button[data-go="book"]').focus()
  iframe.locator('#nav button[data-go="book"]').press('Enter')
  page.wait_for_timeout(900)
  active_page=frame.locator('.page.on').get_attribute('id')
  assert active_page and 'book' in active_page.lower(),active_page
  print('Capturing workspace',width,flush=True)
  page.screenshot(path=str(root/'verification'/f'workspace-{width}.png'),animations='disabled',timeout=90000)
  page.locator('.demo-exit').click()
  expect(page.locator('#try-preview')).to_have_attribute('aria-pressed','false')
  assert page.locator('.demo-workspace').evaluate('(e)=>e.inert')
  expect(page.locator('#screen-portal')).to_have_css('pointer-events','none')
  expect(page.locator('#try-preview')).to_be_focused()
  page.wait_for_timeout(1100)
  page.locator('#try-preview').click(force=True)
  assert frame.evaluate('performance.timeOrigin')==frame_id
  assert frame.locator('.page.on').get_attribute('id')==active_page
  # Repeated toggles and preference changes must leave controls and app usable.
  page.emulate_media(reduced_motion='reduce')
  expect(page.locator('#demo-signal')).to_have_css('display','none')
  page.locator('#try-preview').click(force=True)
  page.locator('#try-preview').click(force=True)
  expect(page.locator('#screen-portal')).to_have_css('pointer-events','auto')
  page.locator('#reset-view').click()
  expect(page.locator('#try-preview')).to_be_hidden()
  assert not page.locator('#museum-frame').evaluate('(e)=>e.classList.contains("is-demo")')
  assert not errors,errors
  if url.endswith('standalone-preview.html'): assert not external,external
  results.append({'width':width,'mode':'standalone' if url.endswith('standalone-preview.html') else 'server','status':'PASS','checks':['entry status and controls','iframe interaction enabled','booking navigation','exit and keyboard focus','state and iframe retained','repeated toggles','reduced motion','return to gallery cleanup','no JavaScript errors']})
  (root/'verification/results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(results[-1]),flush=True)
  context.close()
 context=browser.new_context(viewport={'width':390,'height':844})
 page=context.new_page();page.goto('http://127.0.0.1:8014/',wait_until='networkidle')
 expect(page.locator('#stage-fallback')).to_be_visible()
 expect(page.locator('button[data-explore="jbl"]')).to_be_visible()
 results.append({'width':390,'status':'PASS','checks':['existing lightweight mobile collection retained']})
 browser.close()
(root/'verification'/'results.json').write_text(json.dumps(results,indent=2)+'\n')
