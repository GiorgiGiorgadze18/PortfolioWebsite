# Portfolio showroom v0.14 — Interactive workspace

Based on the unmodified v0.13 archive under ../v13. Try now now combines a subtle camera approach/device alignment, a one-shot light relay into the screen, and a demo control panel replacing project prose. Exit reverses the presentation while retaining the same MeeTab iframe and its state. Reduced motion removes spatial interpolation and the light sweep. The existing lightweight mobile collection is retained below 601px.

Serve this directory with Python http.server, or download and open standalone-preview.html directly in Chrome/Edge. No dependency installation is needed.

MeeTab uses local sample data; account/backend operations stay disabled. See verification/ for new v0.14 checks; v0.13 verification results are retained only with v0.13.

Run the browser regression with `python3 verification/check-preview.py` while serving this directory on port 8014. It requires the environment-provided Python Playwright and system Chromium. Standalone HTML is tested over HTTP with zero external requests; this cloud Chromium policy blocks direct file:// navigation. Original physical-device validation is not claimed.
